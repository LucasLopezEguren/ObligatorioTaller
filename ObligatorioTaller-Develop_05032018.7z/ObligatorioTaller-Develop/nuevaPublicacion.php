<?php

session_start();

require_once("includes/libs/Smarty.class.php");
require_once("includes/class.Conexion.BD.php");
require_once("config/configuracion.php");

$conn = new ConexionBD(MOTOR, SERVIDOR, BASEDATOS, USUARIOBASE, CLAVEBASE);
    if($conn->conectar()){

        $sql = "SELECT * FROM Razas ORDER BY nombre";

        $parametros = array();

        if($conn->consulta($sql, $parametros)){

            $listadoRazas = $conn->restantesRegistros();

            $sql = "SELECT * FROM Especies ORDER BY nombre";

            $parametros = array();

            if($conn->consulta($sql, $parametros)){

                $listadoEsp = $conn->restantesRegistros();

    $smarty = new Smarty();
    
    $smarty->template_dir = "templates";
    $smarty->compile_dir = "templates_c";
    
    $smarty->assign("razas",$listadoRazas);
    $smarty->assign("especies",json_encode($listadoEsp));
    
            
    $smarty->display("nuevaPublicacion.tpl"); 
            }
        }
    }
    
?>