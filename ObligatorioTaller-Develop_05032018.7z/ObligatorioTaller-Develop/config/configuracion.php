<?php

define("MOTOR","mysql");
define("SERVIDOR","localhost");
define("BASEDATOS","mascotas");
define("USUARIOBASE","root");
define("CLAVEBASE","root");

?>
